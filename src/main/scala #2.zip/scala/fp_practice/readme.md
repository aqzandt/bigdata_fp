In this part you will practice functional programming with some small data processing challenges.

This part is worth 15 points.
